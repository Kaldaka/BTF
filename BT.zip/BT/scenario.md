# Catch the Hacker!

## Scenario

A fellow analyst believes that an attacker briefly authenticated to your company WiFi network and might have compromised some machines. Your colleague collected network traffic and ran two Splunk queries that might be helpful in your investigation. Attached are resources provided by the analyst for your evaluation. 

Use the files to answer the following questions. For each answer, include references to supporting evidence (be detailed!).


## Resources
Files:
- ./BT/
- ./BT/dst-and-ports.txt
- ./BT/network.pcap
- ./BT/router-log.jpg
- ./BT/scenario.md
- ./BT/splunk-auth.csv
- ./BT/splunk-exec.csv


## Grading

Questions may be graded on **both** an answer and supporting evidence. Some questions are subjective and can have more than one answer; include reasoning for full credit.
Answer each question in this file, where directed.

Each question has a point value. These may not be exactly our final scoring weights.

Example:

```
#### Q42 - 0 points
42. What are the MAC and IP addresses for the host 'DESKTOP-UT31QVI'?

---------------------
MAC = '5C:26:0A:5B:C3:7B'
IP = 10.24.0.8

This was found by viewing the 'router_log.png' and referencing the first entry, whose Device Name matches the given hostname.
---------------------
```


## Questions (suggested: 85 minutes)

Read every question before answering. Some questions will be easier to answer out of order.
Each section has a suggested time to answer the questions.


### Identify (suggested: 10 minutes)

Use the router logs and the `Statistics > IPv4 Statistics > Destinations and Ports` view in Wireshark (the same information is found in 'dst-and-ports.txt') to answer the questions in this section.

#### Q1 - 3.5 points
1. Who are the actors on this network, and what services might be running? For each machine, fill out an entry in the table below, where `id` is a row number. The first entry is an example. In future questions, you may refer to 'machine 1', where '1' is the id in this table.

Listening/open ports are under 10000 (ten thousand).

| id | IPv4 address | MAC address       | Likely open ports | Likely running services    |
| --- | ------------ | ----------------- | ----------------- | -------------------------- |
| 42 | 10.42.0.8    | 5c:26:0a:5b:c3:7b | 8080, 25          | python website, mailserver |
| **YOUR** | **ANSWERS** | **HERE** |


### Detect (suggested: 60 minutes)

#### Q2 - 5 points
2. Which machines are likely the attacker and victim? Why?

Ex: Machine 1 is the likely attacker and machine 2 is the likely victim. Packets 13100 through 13200 show evidence of a port scan from machine 1 to machine 2.

```
**YOUR ANSWERS HERE**
```


#### Q3 - 5.5 points
3. What recon activity does the attacker perform on this network? What port or machine (choose one) is the single target of this recon? Reference a range of packet numbers.

Ex: The attacker takes pictures of each house in the neighborhood, as seen in the video footage (timestamps 12:34 to 23:45). The target of these pictures is always the door of each house.

```
**YOUR ANSWERS HERE**
```


#### Q4 - 5.75 points
4. What attack was carried out following the recon activities? Cite packets that show this attack, as well as evidence from one of the Splunk query logs that support your conclusions.

Ex: The attacker picked the lock on the victim's front door. We see the attacker hunched over in the 'nestcam-01.png', as well as video footage of them at the door for 2 minutes before going inside.

```
**YOUR ANSWERS HERE**
```


#### Q5 - 5 points
5. Once the attacker gained access to the victim's machine, what executable did they first use to run commands on the host? Cite evidence from 'splunk-exec.csv'.

Ex: The attacker used 'zsh', which is a type of shell. We see this command executing at 05:26:93 PM from the host logs.

```
**YOUR ANSWERS HERE**
```


#### Q6 - 5 points
6. How did the attacker establish persistence on the machine? Either list the built-in command used or the binary that the attacker supplied (or both). Cite evidence from 'splunk-exec.csv' and/or 'network.pcap'.

Ex: The attacker sent 'sharknado.exe' to the victim in packet 15203. They used 'cron' on the victim to schedule a reverse shell connection for persistence. We see evidence of 'cron' being launched from 'zsh' shortly after 05:26 PM in the host logs.

```
**YOUR ANSWERS HERE**
```


### Respond (suggested: 5 minutes)

#### Q7 - 1.75 points
7. What containment strategy (segment, isolate, remove) would you use to respond to this attack? Why?

```
**YOUR ANSWERS HERE**
```


### Recover (suggested: 5 minutes)

#### Q8 - 1.75 points
8. Why should you fully re-install Windows on the victim machine?

```
**YOUR ANSWERS HERE**
```


### Protect (suggested: 5 minutes)

#### Q9 - 1.75 points
9. What is one defensive tool/measure that could prevent this attack? Explain how that tool/measure would have stopped this attack and specifically where in the attacker's steps it would work (cite packet numbers or evidence if necessary).

Ex: One defense could be to lock the doors. This would have stopped the attacker from entering the house (exploitation), as we can see them doing in photo 'nestcam-01.png'.

```
**YOUR ANSWERS HERE**
```


